package com.example.myexamapplication;


import android.app.Dialog;
import android.content.Context;

import androidx.annotation.NonNull;

import com.rilixtech.widget.countrycodepicker.CountryCodePicker;

public class Dialog_message extends Dialog{

//    CountryCodePicker ccp;


    public Dialog_message(@NonNull Context context) {
        super(context);

        this.setContentView(R.layout.dialogmessage);

//        ccp = (CountryCodePicker) findViewById(R.id.ccp);
    }
}

