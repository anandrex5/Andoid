package com.example.myexamapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.rilixtech.widget.countrycodepicker.CountryCodePicker;

import io.michaelrocks.libphonenumber.android.PhoneNumberUtil;
import io.michaelrocks.libphonenumber.android.Phonenumber;

public class ViyaUI extends AppCompatActivity {

    TextView email;

    Button button_next;
    EditText editText;

    CountryCodePicker ccp;
    CheckBox checkBox;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //   setContentView(R.layout.viyaui);
        setContentView(R.layout.viyaui);
        editText = findViewById(R.id.editText);
        ccp = findViewById(R.id.ccp);
        checkBox = findViewById(R.id.checkbox);

        button_next = (Button) findViewById(R.id.next_button);


        if(button_next != null)
        button_next.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.createInstance(ViyaUI.this);


                if (String.valueOf(editText.getText()) != null && !String.valueOf(editText.getText()).isEmpty()) {
                    Phonenumber.PhoneNumber number = new Phonenumber.PhoneNumber();
                    number.setCountryCode(ccp.getSelectedCountryCodeAsInt()).setNationalNumber(Long.parseLong(String.valueOf(editText.getText())));
                    if (phoneNumberUtil.isPossibleNumber(number)) {

                        Intent intent = new Intent(getApplicationContext(), Verifyenterotptwo.class);
                        intent.putExtra("mobile", editText.getText().toString());
                        startActivity(intent);

                        if (checkBox.isChecked()) {
                            Toast.makeText(ViyaUI.this, "You Entered valid number", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ViyaUI.this, "Please Tick on Checkbox", Toast.LENGTH_SHORT).show();

                        }

                    } else {
                        Toast.makeText(ViyaUI.this, "Please Enter valid number", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ViyaUI.this, "Please enter number", Toast.LENGTH_SHORT).show();
                }


            }
        });


//
//    private void dialog_message() {
//
//        new MaterialAlertDialogBuilder(this)
//                .setTitle("Alert")
//                .setMessage("Please Select the Text")
//                .setPositiveButton("GOT IT", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//
//                    }
//                })
//                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//
//                    }
//                })
//                .show();
//
//
//
    }
}
