package com.example.myexamapplication;

public class Text {
}
